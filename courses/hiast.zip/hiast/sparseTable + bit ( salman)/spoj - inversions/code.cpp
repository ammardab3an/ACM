/*
    link: https://www.spoj.com/problems/INVCNT/
*/

#include <bits/stdc++.h>
#define N 10000010
#define ll long long
using namespace std;

ll fenwick[N];
int ar[N];
void update(int pos, int val){
    while( pos < N ){
        fenwick[pos] += val;
        pos += pos&-pos;
    }
}

ll query(int pos){
    ll res = 0;
    while( pos ){
        res += fenwick[pos];
        pos -= pos&-pos;
    }
    return res;
}

int main() {
    int t;
    scanf("%d",&t);
    while(t--) {
        int n;scanf("%d",&n);
        for(int i=1;i<=n;++i){
            scanf("%d",&ar[i]);
        }
        ll ans = 0;
        for(int i=n;i;--i){
            ans += query(ar[i]-1);
            update(ar[i],1);
        }
        printf("%lld\n",ans);
        // or memset
        for(int i=n;i;--i){
            update(ar[i],-1);
        }
    }

    return 0;
}
