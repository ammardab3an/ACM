/*
    link: https://www.spoj.com/problems/RMQSQ/
*/

#include<bits/stdc++.h>
using namespace std;
#define N 100055
#define ll long long
#define MaxLog 20

int st[N][MaxLog];

int main() {

    int n,q;
    scanf("%d",&n);
    for(int i=0; i<n; ++i) {
        scanf("%d",&st[i][0]);
    }
    for(int j=1; j<MaxLog; ++j) {
        for(int i=0;  i + (1<<(j-1)) <n; ++i) {
            st[i][j] = min(st[i][j-1], st[ i + (1<<(j-1)) ][j-1]);
        }
    }
    scanf("%d",&q);
    while(q--) {
        int l,r;
        scanf("%d%d",&l,&r);
        int lg = log2(r - l + 1);
        int ans = min(st[l][lg], st[ r - (1<<lg) + 1 ][lg]);
        printf("%d\n",ans);
    }

}
