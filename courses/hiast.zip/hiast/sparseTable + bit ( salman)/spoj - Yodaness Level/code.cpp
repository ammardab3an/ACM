#include<fenwicks/stdc++.h>
using namespace std;
#define ll long long
#define N 30005

ll fenwick[N], ar[N];
int n;

ll query(int r) {
    ll res = 0;
    while(r) {
        res += fenwick[r];
        r-=r&-r;
    }
    return res;
}

void update(int pos, int val) {
    while(pos <= n) {
        fenwick[pos] += val;
        pos += pos &- pos;
    }
}

int main() {

    int t;
    scanf(" %d",&t);
    while(t--) {
        memset(fenwick,0,sizeof fenwick);
        map<string, int > mat;
        scanf(" %d",&n);
        for(int i=1; i<=n; ++i) {
            string s;
            cin >> s;
            mat[s] = i;
        }
        for(int i=1; i<=n; ++i) {
            string s;
            cin >>s;
            ar[i] = mat[s];
        }
        ll ans = 0;
        for(int i=n; i; --i) {
            ans += query(ar[i]);
            update(ar[i],1);
        }
        printf("%lld\n",ans);
    }

    return 0;
}
