/*
    ** Link: https://www.spoj.com/problems/RPLN/
*/

#include<bits/stdc++.h>
using namespace std;
#define N 100055
#define ll long long
#define MaxLog 20

int st[N][MaxLog];

int main() {
    int t;
    scanf("%d",&t);
    for(int tc = 1 ; tc <= t; ++tc) {
        int n,q;
        scanf("%d%d",&n,&q);
        for(int i=1; i<=n; ++i) {
            scanf("%d",&st[i][0]);
        }
        for(int j=1; j<MaxLog; ++j) {
            for(int i=1;  i + (1<<(j-1)) <=n; ++i) {
                st[i][j] = min(st[i][j-1], st[ i + (1<<(j-1)) ][j-1]);
            }
        }
        printf("Scenario #%d:\n",tc);
        while(q--) {
            int l,r;
            scanf("%d%d",&l,&r);
            int lg = log2(r - l + 1);
            int ans = min(st[l][lg], st[ r - (1<<lg) + 1 ][lg]);
            printf("%d\n",ans);
        }
    }

}
