/*
    Link: https://www.spoj.com/problems/DCEPC705/
*/

#include <bits/stdc++.h>
#define N 200110
#define ll long long
using namespace std;

ll fenwick[N];
pair<int,int> ar[N];
void update(int pos, int val) {
    while( pos < N ) {
        fenwick[pos] += val;
        pos += pos&-pos;
    }
}

ll query(int pos) {
    ll res = 0;
    while( pos ) {
        res += fenwick[pos];
        pos -= pos&-pos;
    }
    return res;
}

int main() {

    int t;
    scanf("%d",&t);
    while(t--) {
        int n,k;
        scanf("%d%d",&n,&k);
        map<int,int>compressed;
        for(int i=1; i<=n; ++i) {
            scanf("%d%d",&ar[i].first, &ar[i].second);
            compressed[ar[i].first] = 1;
            compressed[ar[i].second] = 1;
        }
        int m = 0;
        // compress data
        for(auto i : compressed) {
            compressed[i.first] = ++m;
        }
        sort(ar, ar+n+1);

        int ans = 0;
        for(int i=1; i<=n; ++i) {
            update(compressed[ar[i].second], 1);
            int j = i;
            while( j + 1 <= n && ar[j+1] == ar[i]) {
                j++;
                update(compressed[ar[i].second], 1);
            }

            for(int x = i ; x <= j; ++x) {
                int dom = query(compressed[ar[x].second]) - 1;
                int notDom =(n-1) - dom;

                if( abs(dom - notDom) >= k)
                    ans++;
            }

            i = j;
        }

        for(int i=1; i<=n; ++i) {
            update(compressed[ar[i].second], -1);
        }
        printf("%d\n",ans);


    }

    return 0;
}
