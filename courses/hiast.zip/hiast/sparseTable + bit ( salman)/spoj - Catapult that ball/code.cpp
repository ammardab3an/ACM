/*
    Link : https://www.spoj.com/problems/THRBL/
*/


#include<bits/stdc++.h>
using namespace std;
#define N 100055
#define ll long long
#define MaxLog 20

int st[N][MaxLog];

int main() {

    int n,q;
    scanf("%d%d",&n,&q);
    for(int i=0; i<n; ++i) {
        scanf("%d",&st[i][0]);
    }
    for(int j=1; j<MaxLog; ++j) {
        for(int i=0;  i + (1<<(j-1)) <n; ++i) {
            st[i][j] = max(st[i][j-1], st[ i + (1<<(j-1)) ][j-1]);
        }
    }
    int ans = 0;
    while(q--) {
        int l,r;
        scanf("%d%d",&l,&r);
        l--,r-=2;
        if(l>r) {
            ans ++;
            continue;
        }
        int lg = log2(r - l + 1);
        int mx = max ( st[l][lg], st[ r - (1<<lg) + 1 ][lg] );
        if(mx <= st[l][0])ans++;
    }
    printf("%d\n",ans);

}
