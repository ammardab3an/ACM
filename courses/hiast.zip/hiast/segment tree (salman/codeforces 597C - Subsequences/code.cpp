#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100055

int ar[N];
ll st[4 * N][11];

void update(int v, int l, int r, int pos, ll val, int k) {
    if( l > pos || r < pos )
        return ;

    if( l == r ) {
        st[v][k] = val;
    } else {
        int mid = (l+r)/2;
        update(v * 2, l, mid, pos, val, k );
        update(v * 2 + 1, mid + 1, r, pos, val, k );

        st[v][k] = st[v*2][k] + st[v*2+1][k];
    }
}


ll query( int v, int l, int  r, int ql, int qr, int k) {
    if( l > qr || r < ql ) {
        return 0;
    }
    if( l >= ql && r <= qr ) {
        return st[v][k];
    }

    int mid = (l+r)/2;
    ll left = query(v*2, l, mid, ql, qr, k);
    ll right = query(v*2+1, mid+1, r, ql, qr, k);

    return left + right;
}

int main() {

    int n, k;
    scanf("%d%d",&n,&k);

    for(int i = 1; i <= n; i++) {
        scanf("%d",ar+i);
    }

    for(int i = 1; i <= n; i++) {
        update(1, 1, n, ar[i], 1, 0);
        for(int len = 1; len <= k; len++) {
            ll res = 0;
            if(ar[i] > 1)
                res = query(1, 1, n, 1, ar[i]-1,len - 1);

            update(1,1, n, ar[i], res, len);
        }
    }

    printf("%I64d",query(1,1,n,1,n,k));

    return 0;
}
