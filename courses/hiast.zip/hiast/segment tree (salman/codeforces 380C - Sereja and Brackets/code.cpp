#include <bits/stdc++.h>
#define N 1000110
#define ll long long
using namespace std;

string s;
struct node {
    int opened, closed;
} st[N*4];

node combine(node leftNode, node rightNode) {
    node res;
    int correct = min( rightNode.closed, leftNode.opened );
    res.closed = leftNode.closed + rightNode.closed - correct;
    res.opened = rightNode.opened + leftNode.opened - correct;

    return res;
}

void build(int v, int l, int r) {
    if( l == r ) {
        st[v] = { s[l] == '(', s[l] == ')' };
    } else {
        int mid = (l+r)/2;
        build(v*2, l, mid);
        build(v*2+1, mid+1, r);
        st[v] = combine(st[v*2], st[v*2+1]);
    }
}

node query(int v, int l, int r, int ql, int qr) {
    if( l>qr || r<ql ) {
        return {0,0};
    }
    if( l >= ql && r <= qr ) {
        return st[v];
    }
    int mid = (r+l)/2;
    node leftChild = query( v*2, l, mid, ql, qr);
    node rightChild = query( v*2+1, mid+1, r, ql, qr);

    return combine(leftChild, rightChild);
}

int main() {

    cin >> s;
    int n = s.size();
    build(1, 0, n-1);
    int q;
    cin >> q;
    while(q--){
        int l, r;
        cin >> l >> r;
        l--,r--;
        int len = ( r - l + 1);

        node ans = query(1 , 0 , n - 1 , l , r );
        cout << len - ans.closed - ans.opened << "\n";
    }

    return 0;
}
