#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100005

struct node {
    int indexA, indexB;
    node() {}
    node(int a, int b):indexA(a), indexB(b) {}
} st[4*N];

int A[N], B[N],n,m;

void push(int v) {

    if(st[v].indexA == 0) // nothing to push
        return;
    st[v*2] = st[v];
    st[v*2+1] = st[v];
    st[v] = {0,0};
}


void update(int v, int l,int r,  int ql,int qr, node val) {

    if( l >= ql && r <= qr ) {
        st[v] = val;
        return;
    }
    if( l > qr || r < ql )
        return;
    push(v);

    int md = (l + r) / 2;
    update( v * 2, l, md, ql, qr, val );
    update( v * 2 + 1, md + 1, r, ql, qr, val );

}

node query(int v, int l, int r, int p) {
    if( r < p || l > p) {
        return {0,0};
    }

    if( l == r) {
        return st[v];
    }
    int md = ( l + r ) / 2;
    push(v);

    node left = query(v * 2, l, md, p);
    node right = query(v * 2 + 1, md + 1, r, p);

    return left.indexA != 0 ? left : right ;
}


int main() {

    scanf("%d%d",&n,&m);
    for(int i=1; i<=n; ++i) {
        scanf("%d",A+i);
    }
    for(int i=1; i<=n; ++i) {
        scanf("%d",B+i);
    }
    for(int i=1; i<=m; ++i) {
        int t, x, y, q;
        scanf("%d",&t);
        if(t==1) {
            scanf("%d%d%d",&x,&y,&q);
            update(1, 1, n, y, y + q - 1, {x, y} );
        } else {
            scanf("%d",&x);
            node res = query(1, 1, n, x);
            int ans;
            if(!res.indexA)
                ans = B[x];
            else
                ans = A[res.indexA + (x - res.indexB)];
            printf("%d\n",ans);
        }

    }

    return 0;
}
