#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100055
/*
    first index i in array A where A[1] + A[2] + ... + A[i] >= x
*/
int ar[N], st[4 * N];

void build(int v, int l, int r) {
    if( l == r ) {
        st[v] = ar[l];
    } else {
        int mid = ( l + r ) / 2;
        build(v*2, l, mid);
        build(v*2+1, mid +1, r);

        st[v] = st[v*2] + st[v*2+1];
    }
}

void update(int v, int l, int r, int pos, int val) {
    if( l > pos || r < pos )
        return ;

    if( l == r ) {
        st[v] = val;
    } else {
        int mid = (l+r) / 2;
        update(v * 2, l, mid, pos, val );
        update(v * 2 + 1, mid + 1, r, pos, val );

        st[v] = st[v*2] + st[v*2+1];
    }
}


int query( int v, int l, int  r, int x) {

    if( l == r ) {
        return l;
    }

    int mid = ( l + r ) / 2;
    if(st[v*2] >= x) {
        return query(v*2, l, mid, x);
    } else {
        return query(v*2+1, mid+1, r, x - st[v*2]);
    }

}

int main() {

    int n;
    scanf("%d",&n);

    for(int i = 1; i <= n; i++) {
        scanf("%d",ar+i);
    }
    build(1, 1, n);

    // queries
    int q;
    scanf("%d",&q);
    while(q--) {
        int x;
        scanf("%d", &x);
        int ans = 0;

        if(x > st[1] || x < ar[1]) { // too big or too small
            ans = -1;
        } else {
            ans = query(1,1,n,x);
        }
        printf("%d\n",ans);
    }

    return 0;
}
