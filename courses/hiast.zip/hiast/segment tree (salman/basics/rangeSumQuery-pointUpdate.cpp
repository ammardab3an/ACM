#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100055

int ar[N], st[4 * N];

void build(int v, int l, int r) {
    if( l == r ) {
        st[v] = ar[l];
    } else {
        int mid = ( l + r ) / 2;
        build(v*2, l, mid);
        build(v*2+1, mid +1, r);

        st[v] = st[v*2] + st[v*2+1];
    }
}

void update(int v, int l, int r, int pos, int val) {
    if( l > pos || r < pos )
        return ;

    if( l == r ) {
        st[v] = val;
    } else {
        int mid = (l+r) / 2;
        update(v * 2, l, mid, pos, val );
        update(v * 2 + 1, mid + 1, r, pos, val );

        st[v] = st[v*2] + st[v*2+1];
    }
}


int query( int v, int l, int  r, int ql, int qr) {
    if( l > qr || r < ql ) {
        return 0;
    }
    if( l >= ql && r <= qr ) {
        return st[v];
    }

    int mid = ( l + r ) / 2;
    int left = query(v*2, l, mid, ql, qr);
    int right = query(v*2+1, mid+1, r, ql, qr);

    return left + right;
}

int main() {

    int n;
    scanf("%d",&n);

    for(int i = 1; i <= n; i++) {
        scanf("%d",ar+i);
    }
    build(1, 1, n);

    // queries
    int q;
    scanf("%d",&q);
    while(q--) {
        int L, R;
        scanf("%d%d", &L, &R);
        int sum = query(1,1,n,L,R);
        printf("%d\n",sum);
    }

    return 0;
}
