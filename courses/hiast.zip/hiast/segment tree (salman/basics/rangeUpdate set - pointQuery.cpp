#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100055

int ar[N], st[4 * N];
bool marked[N];

void push(int v){
    if(!marked[v])return;
    st[v*2] = st[v*2+1] = st[v];
    marked[v*2] = marked[v*2+1] = true;
    marked[v] = false;
}


void update(int v, int l, int r, int ql, int qr , int val) {
    if( l > qr || r < ql )
        return ;


    if( l >= ql && r <= qr ) {
        st[v] = val;
        marked[v] = true;
    } else {
        push(v);

        int mid = (l+r) / 2;
        update(v * 2, l, mid, ql , qr , val );
        update(v * 2 + 1, mid + 1, r, ql , qr , val );
    }
}


int query( int v, int l, int  r, int pos) {
    if( l > pos || r < pos ) {
        return -1e9; // return too small value
    }
    if( l == r) {
        return st[v];
    }
    push(v);

    int mid = ( l + r ) / 2;
    int left = query(v*2, l, mid, pos);
    int right = query(v*2+1, mid+1, r, pos);

    return max(left, right); // max between -1e9 and correct value
}

int main() {

    int n;
    scanf("%d",&n);

    for(int i = 1; i <= n; i++) {
        scanf("%d",ar+i);
        update(1,1,n,i,i,ar[i]);
    }

    // queries
    int q;
    scanf("%d",&q);
    while(q--) {
        int t;
        scanf("%d", &t);
        if(t==1){
            int l , r , val;
            scanf("%d%d%d",&l,&r,&val); // set all elements between [l,r] to val
            update(1,1,n,l,r,val);
        }else{
            int pos;
            scanf("%d",&pos);
            int ans = query(1,1,n,pos); // get ar[pos]
            printf("%d\n",ans);
        }
    }

    return 0;
}
