#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100055

int ar[N];

struct node {
    // max and its frequency
    int mx, freq;
} st[4*N];

node combine(node a, node b){
    if(a.mx == b.mx){
        return { a.mx , a.freq + b.freq };
    }
    return a.mx > b.mx ? a : b;
}

void build(int v, int l, int r) {
    if( l == r ) {
        st[v] = {ar[l] , 1};
    } else {
        int mid = ( l + r ) / 2;
        build(v*2, l, mid);
        build(v*2+1, mid +1, r);

        st[v] = combine(st[v*2], st[v*2+1]);
    }
}

void update(int v, int l, int r, int pos, node val) {
    if( l > pos || r < pos )
        return ;

    if( l == r ) {
        st[v] = val;
    } else {
        int mid = (l+r) / 2;
        update(v * 2, l, mid, pos, val );
        update(v * 2 + 1, mid + 1, r, pos, val );

        st[v] = combine( st[v*2], st[v*2+1] );
    }
}


node query( int v, int l, int  r, int ql, int qr) {
    if( l > qr || r < ql ) {
        // return -infinity
        return {-1e9 , 0};
    }
    if( l >= ql && r <= qr ) {
        return st[v];
    }

    int mid = ( l + r ) / 2;
    node left = query(v*2, l, mid, ql, qr);
    node right = query(v*2+1, mid+1, r, ql, qr);

    return combine(left, right);
}

int main() {

    int n;
    scanf("%d",&n);

    for(int i = 1; i <= n; i++) {
        scanf("%d",ar+i);
    }
    build(1, 1, n);

    // queries
    int q;
    scanf("%d",&q);
    while(q--) {
        int L, R;
        scanf("%d%d", &L, &R);
        node res = query(1,1,n,L,R);
        printf("max element: %d and it's occurrences: %d\n",res.mx, res.freq);
    }

    return 0;
}
