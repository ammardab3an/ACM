#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 200005
int segTree[4*N],ar[N], n, m;
int goal = 0;
void build(int v, int l, int r, bool _or) {
    if(l==r) {
        segTree[v] = ar[l];
        return;
    }
    int md = (l+r)/2;
    build(v*2, l, md, _or ^ 1);
    build(v*2+1, md+1, r, _or ^ 1);
    if(_or)
        segTree[v] = segTree[v*2] | segTree[v*2+1];
    else
        segTree[v] = segTree[v*2] ^ segTree[v*2+1];
}

void update(int v, int l, int r, bool _or, int p, int val) {
    if(l==r) {
        segTree[v] = ar[l];
        return;
    }
    if( l > p || r < p)return ;

    int md = (l+r)/2;
    update(v*2, l, md, _or ^ 1, p, val);
    update(v*2+1, md+1, r, _or ^ 1, p, val);
    if(_or)
        segTree[v] = segTree[v*2] | segTree[v*2+1];
    else
        segTree[v] = segTree[v*2] ^ segTree[v*2+1];

}

int main() {
    scanf("%d%d",&n,&m);
    bool _or = n&1;
    n = 1<<n;
    for(int i=1; i<=n; ++i) {
        scanf("%d",ar+i);
    }
    build(1, 1, n, _or);
    while(m--) {
        int x,y;
        scanf("%d%d",&x,&y);
        ar[x] = y;
        update(1, 1, n, _or, x, y);
        printf("%d\n",segTree[1]);
    }
    return 0;
}
