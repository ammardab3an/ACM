#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define N 100005
#define node vector<ll>

node st[4*N];
int n, ar[N];
ll k;

// merge two sorted arrays (cost  O (n) )
node combine(node &res, node &a, node &b) {
    int i = 0, j = 0;
    while(i<a.size() && j < b.size()) {
        if(a[i] < b[j])res.push_back(a[i++]);
        else res.push_back(b[j++]);
    }
    while(i<a.size()) {
        res.push_back(a[i++]);
    }
    while(j<b.size()) {
        res.push_back(b[j++]);
    }
    return res;
}

void build(int v, int l, int r) {
    if(l == r) {
        st[v] = {ar[l]};
    } else {
        int md = (l + r)>>1;
        build(v*2, l, md);
        build(v*2+1,md+1,r);
        combine(st[v], st[v*2], st[v*2+1]);
    }
}

ll query(int v, int l,int r, int ql, int qr, int val, bool inverse = false) {
    if( l >= ql && r <= qr ) {
        if(!inverse) // elements less then val
            return upper_bound(st[v].begin(), st[v].end(), val-1)-st[v].begin();
        else // elements greater then val
            return st[v].end() - upper_bound(st[v].begin(), st[v].end(), val);
    }
    if( l > qr || r < ql )
        return 0;

    int md = (l+r) / 2;
    return    query(v*2  , l   , md , ql , qr, val , inverse)
            + query(v*2+1, md+1, r  , ql , qr, val ,inverse);
}

int main() {

    scanf("%d %I64d",&n,&k);
    for(int i=1; i<=n; ++i) {
        scanf("%d",ar+i);
    }
    build(1, 1, n);

    // total inversions in the array
    ll inversions = 0, ans = 0;
    for(int i=1; i<n; ++i) {
        inversions += query(1, 1, n, i,n, ar[i]);
    }

    // two pointers
    int i = 1, j = 2;
    while( j <= n ) {
        if(inversions <= k) { // if current inversions of sequence 1,2,..i,j,j+1,..,n  <= k then all elements after j is acceptable
            ans += (n-j+1);
            if(i+1==j) {
                i++;
                j++;
            } else {
                i++;
                inversions += query(1, 1, n, j, n, ar[i]); // add no.of elements less than ar[i] in range [j,n]
                inversions += query(1, 1, n, 1, i, ar[i], true); // add no.of elements grater than ar[i] in range [1,i]
            }
        } else {
            inversions -= query(1, 1, n, j+1, n, ar[j]); // subtract no.of elements less than ar[i] in range [j,n]
            inversions -= query(1, 1, n, 1, i, ar[j], true); // subtract no.of elements grater than ar[i] in range [1,i]
            j++;
        }

    }
    cout << ans;

    return 0;
}
