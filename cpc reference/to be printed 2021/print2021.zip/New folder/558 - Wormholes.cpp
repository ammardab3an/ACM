// Problem: 558 - Wormholes

int n, m;
iii edges[MMAX];
int dist[NMAX];

int32_t main(){

    int t; cin >> t; while(t--){

        cin >> n >> m;
        for(int i = 0; i < m; i++){
            int u, v, c;
            cin >> u >> v >> c;
            edges[i] = {c, {u, v}};
        }

        memset(dist, INF, sizeof dist);

        for(int i = 0; i < n-1; i++){
            for(int j = 0; j < m; j++){

                int u = edges[j].second.first;
                int v = edges[j].second.second;
                int c = edges[j].first;

                if(dist[v] > dist[u] + c){
                    dist[v] = dist[u] + c;
                }
            }
        }

        bool neg = false;
        for(int j = 0; j < m; j++){

            int u = edges[j].second.first;
            int v = edges[j].second.second;
            int c = edges[j].first;

            if(dist[v] > dist[u] + c){
                neg = true;
                break;
            }
        }

        cout << ( neg ? "possible" : "not possible" ) << endl;

    }
}