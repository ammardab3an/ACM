// Problem: Inversion Count

int n;
int arr[NMAX];
int tmp[NMAX];

lli merge(int l, int mid, int r){
    
    int i = l;
    int j = mid+1;
    int k = 0;
    
    lli cnt = 0;
    
    while((i <= mid) && (j <= r)){
        if(arr[i] < arr[j]){ // arr[i] != arr[j]
            tmp[k++] = arr[i++];
        }
        else{
            tmp[k++] = arr[j++];
            cnt += mid - i + 1;
        }
    }
    
    while(i <= mid) tmp[k++] = arr[i++];
    while(j <=  r ) tmp[k++] = arr[j++];
    
    for(int i = l, j = 0; i <= r; i++, j++)
        arr[i] = tmp[j];
        
    return cnt;
}

lli go(int l, int r){
    
    if(l >= r) return 0;
    
    lli cnt = 0;
    
    int mid = (l+r)/2;
    
    cnt += go(l, mid);
    cnt += go(mid+1, r);    
    
    cnt += merge(l, mid, r);
    
    return cnt;
}

int32_t main(){
    
    int t; cin >> t; while(t--){

        cin >> n;
        for(int i = 0; i < n; i++) cin >> arr[i];
        
        cout << go(0, n-1) << endl;
    }	
}
