// Problem: 12470 - Tribonacci

struct matrix{

    lli arr[3][3] = {0};

    matrix operator * (const matrix &other){

        matrix product;

        for(int i = 0; i < 3; i++)
        for(int j = 0; j < 3; j++)
        for(int k = 0; k < 3; k++)
            (product.arr[i][k] += arr[i][j] * other.arr[j][k]) %= lli(1e9 + 9);
            
        return product;
    }
};

matrix fast_power(matrix a, lli p){

    matrix product;
    for(int i = 0; i < 3; i++) product.arr[i][i] = 1;
	
    while(p){
        if(p&1) product = product * a;
        a = a*a;
        p /= 2;
    }

    return product;
}

int32_t main(){
    
    lli n;
    while(cin >> n, n){
    	
        matrix single;
        single.arr[0][0] = 0; 
        single.arr[0][1] = 1;
        single.arr[0][2] = 0;
        single.arr[1][0] = 0;
        single.arr[1][1] = 0;
        single.arr[1][2] = 1;
        single.arr[2][0] = 1;
        single.arr[2][1] = 1;
        single.arr[2][2] = 1;

        matrix initial;
        initial.arr[0][0] = 0;
        initial.arr[1][0] = 1;
        initial.arr[2][0] = 2;
		
        matrix ans = fast_power(single, n-1LL) * initial;

        cout << ans.arr[0][0] << endl;
    }
}