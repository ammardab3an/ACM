
// sqrt - frequency 

int n, m, cans;
int arr[NMAX];
int cnt[NMAX];
int frq[NMAX];
int ans[MMAX];

struct query{
    int lo, hi, idx;
    bool operator < (query other){
        if(lo/BLOCK != other.lo/BLOCK) return lo < other.lo;
        return lo/BLOCK % 2 ? hi > other.hi : hi < other.hi;
    }
} q[MMAX];

void add(int idx){
    frq[cnt[arr[idx]]]--;
    frq[++cnt[arr[idx]]]++;
    cans = max(cans, cnt[arr[idx]]);
}

void rem(int idx){
    frq[cnt[arr[idx]]]--;
    frq[--cnt[arr[idx]]]++;
    if(!frq[cans]) cans--;
}

int32_t main(){


    while(cin >> n >> m){

        cans = 0;
        memset(cnt, 0, sizeof cnt);
        memset(frq, 0, sizeof frq);

        for(int i = 0; i < n; i++) {
            cin >> arr[i];
            arr[i] += 1e5;
        }

        for(int i = 0; i < m; i++) {
            cin >> q[i].lo >> q[i].hi;
            q[i].lo--, q[i].hi--, q[i].idx = i;
        }

        sort(q, q+m);

        int l = 1, r = 0;

        for(int i = 0; i < m; i++){

            int cl = q[i].lo;
            int cr = q[i].hi;
            int ci = q[i].idx;

            while(r < cr) add(++r);
            while(cl < l) add(--l);
            while(cr < r) rem(r--);
            while(l < cl) rem(l++);

            ans[ci] = cans;
        }

        for(int i = 0; i < m; i++) cout << ans[i] << endl;
    }
}
