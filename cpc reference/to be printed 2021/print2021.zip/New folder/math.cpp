
int gcd(int a,int b)
{
if(b==0) return a;
return gcd(b,a%b);
}

int lcm(int a,int b)
{
    return a*b/gcd(a,b);
}

bool isPrime(ll a)
{
   if(a<1000000) return bs[a];
       ll b=sqrt(a)+2;
       for(int i=0;i<prims.size();i++)
        if(prims[i]>b) return true;
      else if(a%prims[i]==0) return false;
}

bool is_square(ll n)
{
    ll sqr=sqrt(n)+0.00001;
    if(sqr*sqr==n) return true;
    return false;

}

int numDiv(ll N)
{
 ll PF_idx=0; ll pf=prims[PF_idx]; int ans=1;

  while(pf*pf<=N)
 {
    int cnt=0;
    while(N%pf==0){N/=pf; cnt++;}
    ans*=(cnt+1);
    PF_idx++;
     pf=prims[PF_idx];
 }
  if(N!=1)  ans*=2;
    return ans;
}


int x,y,d;
void bezout (int a,int b)
{
    if(b==0) { x=1; y=0; d=a; return; }
    bezout(b,a%b);
    int x1=y;
    int y1=x-(a/b)*y;
    x=x1;
    y=y1;
}


ll C_[1000][1000];
ll modCombinatorics=1000000007;
void Combinatorics(int n)
{
    memset(C_,0,sizeof C_);

    for(int i=0;i<=n;i++)
        C_[i][0]=1;

    for(int i=1;i<=n;i++)
        for(int j=1;j<=n;j++)
        C_[i][j]=(C_[i-1][j]+C_[i-1][j-1])%modCombinatorics;
}
