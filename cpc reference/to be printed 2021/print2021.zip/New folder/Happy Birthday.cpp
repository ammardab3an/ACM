Happy Birthday UVA - 11373 


bool intersect(const point &a, const point &b, const point &p, const point &q,
              point &ret) {
    //handle degenerate cases (2 parallel lines, 2 identical lines,   line is 1 point)
    double d1 = cross(p - a, b - a);
    double d2 = cross(q - a, b - a);
    ret = (d1 * q - d2 * p) / (d1 - d2);
    if(fabs(d1 - d2) > EPS) return 1;
    return 0;
}

//get angle opposite to side a
double cosRule(double a, double b, double c) {
        // Handle denom = 0
	double res = (b * b + c * c - a * a) / (2 * b * c);
	if ( fabs(res-1)<EPS)
                res = 1 ;
        if ( fabs(res+1)<EPS)
                res = -1 ;
	return acos(res);
}

int circleLineIntersection(const point& p0, const point& p1, const point& cen,
		double rad, point& r1, point & r2) {

	// handle degenerate case if p0 == p1
	double a, b, c, t1, t2;
	a = dot(p1-p0,p1-p0);
	b = 2 * dot(p1-p0,p0-cen);
	c = dot(p0-cen,p0-cen) - rad * rad;
	double det = b * b - 4 * a * c;
	int res;
	if (fabs(det) < EPS)
		det = 0, res = 1;
	else if (det < 0)
		res = 0;
	else
		res = 2;
	det = sqrt(det);
	t1 = (-b + det) / (2 * a);
	t2 = (-b - det) / (2 * a);
	r1 = p0 + t1 * (p1 - p0);
	r2 = p0 + t2 * (p1 - p0);
	return res;
}

double r , h , x ,y ;
point p[4] ;

bool cmp ( point &a , point &b ){
    if ( a.X == b.X )
        return a.Y < b.Y ;
    return a.X < b.X ;
}

ld CenterSectorArea( double theta , double r ){
    return r*r*theta/2.0 ;
}

double triangleArea3points(const point& a, const point& b, const point& c) {
	return fabs(cross(a,b) + cross(b,c) + cross(c,a)) / 2;
}

int main()
{

    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    #ifdef LOCAL
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif // LOCAL
    cout << fixed << setprecision(2) ;
    while ( cin >> r >> h ){
        for ( int i = 0 ; i < 4 ; i++ ){
            cin >> x >> y ;
            p[i] = {x,y} ;
        }
        point InterCen ;
        point zero = {0,0} ;
        bool b = intersect(p[0] , p[1] , p[2] , p[3] , InterCen ) ;
        point cut[2][2] ;
        for ( int i = 0 , j = 0 ; i < 4 ; i += 2 ,j++ )
            b = circleLineIntersection(p[i] , p[i+1] , zero , r , cut[j][0] , cut[j][1] ) ;

        sort ( cut[0] , cut[0]+2 ,cmp ) ;
        sort ( cut[1] , cut[1]+2 ,cmp ) ;

        ld theta[4] ;
        pair < point , point > thetapnt[4] ;
        theta[0] = cosRule(length(cut[0][0]-cut[1][0]) , length(InterCen-cut[1][0]) , length(cut[0][0]-InterCen) ) ;
        thetapnt[0] = {cut[0][0],cut[1][0]} ;

        theta[1] = cosRule(length(cut[0][0]-cut[1][1]) , length(InterCen-cut[1][1]) , length(cut[0][0]-InterCen) ) ;
        thetapnt[1] = {cut[0][0],cut[1][1]} ;

        theta[2] = cosRule(length(cut[0][1]-cut[1][0]) , length(InterCen-cut[1][0]) , length(cut[0][1]-InterCen) ) ;
        thetapnt[2] = {cut[0][1],cut[1][0]} ;

        theta[3] = cosRule(length(cut[0][1]-cut[1][1]) , length(InterCen-cut[1][1]) , length(cut[0][1]-InterCen) ) ;
        thetapnt[3] = {cut[0][1],cut[1][1]} ;

//        cout << theta[0]*180/M_PI << ' ' << theta[1]*180/M_PI << ' ' << theta[2] *180/M_PI << ' ' << theta[3]*180/M_PI << '\n' ;
        ld sec[4] , mx = 0 , mn = 1e9 , tmp = 0 ;
        ld totalAngles = 6.28 , maxangle = 0 ;
        for ( int i = 0 ; i < 4 ; i++ ){
            ld tt = cosRule( length(thetapnt[i].F-thetapnt[i].S) , length(thetapnt[i].F-zero) , length(zero-thetapnt[i].S)  ) ;
            totalAngles -= tt ;
            maxangle = max ( maxangle , tt ) ;
        }
        for ( int i = 0 ; i < 4 ; i++ ){
            ld tt = cosRule( length(thetapnt[i].F-thetapnt[i].S) , length(thetapnt[i].F-zero) , length(zero-thetapnt[i].S)  ) ;
            if ( tt == maxangle )
                tt += max ( (ld)0.0 , totalAngles ) ;
            sec[i] = CenterSectorArea( tt , length(vec(zero,thetapnt[i].F)) ) ;
            if ( tt*180/M_PI <= 180 )
                sec[i] -= triangleArea3points( zero , thetapnt[i].F , thetapnt[i].S ) ;
            sec[i] += triangleArea3points( InterCen , thetapnt[i].F , thetapnt[i].S ) ;

            tmp += sec[i] ;
            mx = max ( mx , sec[i] ) ;
            mn = min ( mn , sec[i] ) ;
        }
        mx += max ( (ld)0,  r*r*M_PI  - tmp ) ;
        cout << fixed << setprecision(2) << mx*h << ' ' << mn*h << "\n" ;
   }

}