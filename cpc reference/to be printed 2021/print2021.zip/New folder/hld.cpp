// Problem: L. Subway Lines
// hld with segment

int n, log_n;
vi adj[NMAX];
int depth[NMAX];
int par[NMAX][LOG_MAX];
int sz[NMAX], in[NMAX], nxt[NMAX], t;
int tree[NMAX << 2];
int lazy[NMAX << 2];

void push(int nd, int l, int r){
    
    if(lazy[nd] == -1) return;
    
    tree[nd] = (r-l+1) * lazy[nd];
    
    if(l != r){
        lazy[nd*2] = lazy[nd];
        lazy[nd*2+1] = lazy[nd];
    }
    
    lazy[nd] = -1;
}

void update(int nd, int l, int r, int q_l, int q_r, int v){
    
    push(nd, l, r);
    
    if(r < q_l || q_r < l) return;
    
    if(q_l <= l && r <= q_r){
        lazy[nd] = v;
        push(nd, l, r);
        return;
    }
    
    int mid = (l+r)/2;
    update(nd*2, l, mid, q_l, q_r, v);
    update(nd*2+1, mid+1, r, q_l, q_r, v);
    
    tree[nd] = tree[nd*2] + tree[nd*2+1];
}

int query(int nd, int l, int r, int q_l, int q_r){
    
    push(nd, l, r);
    
    if(r < q_l || q_r < l) return 0;
    
    if(q_l <= l && r <= q_r) return tree[nd];
    
    int mid = (l+r)/2;
    int st_path = query(nd*2, l, mid, q_l, q_r);
    int nd_path = query(nd*2+1, mid+1, r, q_l, q_r);
    
    return st_path + nd_path;
}

void dfs(int u, int p){
    
    sz[u] = 1;
    
    for(auto &v : adj[u]) if(v != p){
        
        depth[v] = depth[u]+1;
        
        par[v][0] = u;
        for(int i = 1; i < log_n; i++){
            par[v][i] = par[par[v][i-1]][i-1];
        }
        
        dfs(v, u);
        sz[u] += sz[v];
        
        if((adj[u][0] == p) || (sz[adj[u][0]] < sz[v])){
            swap(adj[u][0], v);
        }
    }    
}

void dfs_hld(int u, int p){
    
    in[u] = t++;
    
    for(auto v : adj[u]) if(v != p){
        nxt[v] = (v==adj[u][0]) ? nxt[u] : v;
        dfs_hld(v, u);
    }    
}

void hld_update(int u, int v, int val){
    
    while(nxt[u] != nxt[v]){
        
        if(depth[nxt[u]] < depth[nxt[v]]){
            swap(u, v);
        }
        update(1, 0, n-1, in[nxt[u]], in[u], val);
        u = par[nxt[u]][0];
    }
    
    if(depth[u] < depth[v]) swap(u, v);
    update(1, 0, n-1, in[v], in[u], val);

}

int hld_query(int u, int v){
    
    int ans = 0;
    
    while(nxt[u] != nxt[v]){
        
        if(depth[nxt[u]] < depth[nxt[v]]){
            swap(u, v);
        }
        ans += query(1, 0, n-1, in[nxt[u]], in[u]);
        u = par[nxt[u]][0];
    }
    
    if(depth[u] < depth[v]) swap(u, v);
    ans += query(1, 0, n-1, in[v], in[u]);
    
    return ans;
}

int32_t main(){
    
    int q;
    cin >> n >> q;
    
    log_n = ceil(log2(double(n)));
    
    for(int i = 0; i < n-1; i++){
        
        int u, v;
        cin >> u >> v;
        u--, v--;
        
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    
    dfs(0, -1);
    dfs_hld(0, -1);
    memset(lazy, -1, sizeof lazy);
    
    while(q--){
        
        int a, b, x, y;
        cin >> a >> b >> x >> y;
        a--, b--, x--, y--;
        
        hld_update(a, b, 1);
        
        int ans = hld_query(x, y);
        
        hld_update(a, b, 0);
        
        cout << ans << endl;
    }
}