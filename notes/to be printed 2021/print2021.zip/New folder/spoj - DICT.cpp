// Problem: trie - Search in the dictionary!

struct node{
    node *nxt[26];
    bool val;
    node(){
        memset(nxt, 0, sizeof nxt);
        val = 0;
    }
};

void add(node *root, string str){
    
    node *cur = root;
    
    for(int i = 0; i < str.size(); i++){
        
        if(!cur->nxt[str[i]-'a']) 
            cur->nxt[str[i]-'a'] = new node();
        
        cur = cur->nxt[str[i]-'a'];
    }
    
    cur->val = 1;
}

int dfs(node *cur, string str){
    
    int cnt = 0;
    
    if(cur->val){
        cout << str << endl;
        cnt++;
    }
    
    for(int i = 0; i < 26; i++){
        
        if(cur->nxt[i]) cnt += dfs(cur->nxt[i], str + string(1, 'a' + i));
    }    
    
    return cnt;
}

bool query(node *root, string str){
    
    node *cur = root;
    
    for(int i = 0; i < str.size(); i++){
        
        if(!cur->nxt[str[i]-'a']) return 0;
        
        cur = cur->nxt[str[i]-'a'];
    }
    
    int tot = 0;
    for(int i = 0; i < 26; i++) if(cur->nxt[i]) tot += dfs(cur->nxt[i], str + string(1, 'a' + i));
    return tot;
}

int32_t main(){
    
    fastIO;
    
#ifdef LOCAL
    freopenI;
    freopenO;
#endif
    
    int n;
    cin >> n;
    
    node *root = new node();
    
    for(int i = 0; i < n; i++){
        
        string word;
        cin >> word;
        
        add(root, word);
    }
    
    int tt = 1;
    int m; cin >> m; while(m--){
        
        cout << "Case #" << tt++ << ":" << endl;
        
        string pre;
        cin >> pre;
        
        bool que = query(root, pre);
        
        if(!que){
            cout << "No match." << endl;
        }
    }
    
}

/*
  arrays sizes 
  INFLL & 1ll
  there is something called long long.
  if its an interactive problem : #define endl '\n'
  
  
  notes : 
  
  
*/    
