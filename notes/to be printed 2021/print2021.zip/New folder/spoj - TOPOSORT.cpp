// Problem: Topological Sorting

int n, m;
vi adj[NMAX];
stack<int> st;
int vis[NMAX];
bool bad = false;

void dfs(int nd){
    
    if(bad) return;
        
    vis[nd] = -1;
    
    for(auto nxt : adj[nd]){
        
        if(vis[nxt] == -1){
            bad = true;
            return;
        }
        
        if(vis[nxt] == 0){
            dfs(nxt);
        }
    }
    
    vis[nd] = 1;
    
    st.push(nd);                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            
}

int32_t main(){
    
    cin >> n >> m;
    for(int i = 0; i < m; i++){
        int u, v;
        cin >> u >> v;
        u--, v--;
        adj[u].push_back(v);
    }
    
    for(int i = 0; i < n; i++) 
        sort(adj[i].begin(), adj[i].end(), greater<int>());
        
    for(int i = n-1; i >= 0; i--) if(!vis[i])
        dfs(i);
    
    if(bad){
        cout << "Sandro fails." << endl;
    }
    else{
        while(!st.empty()){
            cout << st.top()+1 << ' ';
            st.pop();
        }
    }
}
