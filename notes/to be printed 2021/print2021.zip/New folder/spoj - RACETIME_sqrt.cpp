// Problem: A - Race Against Time

int n, q;
int arr[NMAX];
int base[NMAX];

int32_t main(){

    cin >> n >> q;
    for(int i = 0; i < n; i++){
        cin >> arr[i];
        base[i] = arr[i];
    }
    
    int block = ceil(sqrt(double(n)));
    
    while(n%block){
        arr[n] = INF;
        base[n] = INF;
        n++;    
    }
    
    for(int i = 0; i < n/block; i++){
        sort(base + i*block, base + (i+1)*block);
    }
    
    while(q--){
        
        char c;
        cin >> c;
        
        if(c == 'C'){
            
            int l, r, x;
            cin >> l >> r >> x;
            l--, r--;
            
            int cans = 0;
            
            for(int i = l/block+1; i < r/block; i++){
                cans += (upper_bound(base + i*block, base + (i+1)*block, x) - (base + i*block));
            }
            
            for(int i = l; (i/block == l/block) && (i <= r); i++) if(arr[i] <= x) cans++;
            if(l/block != r/block)
            for(int i = r; i/block == r/block; i--) if(arr[i] <= x) cans++;
            
            cout << cans << endl;
        }
        else{
            
            int i, x;
            cin >> i >> x;
            i--;
            
            int b = i/block;
            *lower_bound(base + b*block, base + (b+1)*block, arr[i]) = x;
            sort(base + b*block, base + (b+1)*block);
            arr[i] = x;
        }
        
    }
}
