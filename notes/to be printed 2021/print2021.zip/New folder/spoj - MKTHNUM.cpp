// Problem: persistent seg K-th Number

struct node{
    
    int count;
    node *left, *right;
    
    node(int count, node *left, node *right): 
        count(count), left(left), right(right) {}
        
    node* insert(int l, int r, int w);
};

int n, m;
int arr[NMAX];
int comp[NMAX], comp_sz;
node* root[NMAX];
node* null = new node(0, nullptr, nullptr);

node* node::insert(int l, int r, int w){
        
    if(w < l || r < w){
        return this;
    }
            
    if(l == r){
        return new node(this->count+1, null, null);
    }
    
    int mid = (l+r)/2;
    
    node *left = this->left->insert(l, mid, w);
    node *right = this->right->insert(mid+1, r, w);
    return new node(this->count+1, left, right);
}
    
int query(node *a, node *b, int l, int r, int k){
    
    if(l == r){
        return l;
    }    
    
    int mid = (l+r)/2;
    int cur_count = a->left->count - b->left->count;
    
    if(cur_count >= k){
        return query(a->left, b->left, l, mid, k);
    }
    else{
        return query(a->right, b->right, mid+1, r, k-cur_count);
    }
}

int32_t main(){
    
    cin >> n >> m;
    for(int i = 0; i < n; i++){
        cin >> arr[i];
        comp[comp_sz++] = arr[i];
    }
    
    compress();
    null->left = null->right = null;
    
    for(int i = 0; i < n; i++){
        root[i] = ((i==0)?null:root[i-1])->insert(0, comp_sz-1, arr[i]);
    }
    
    while(m--){
        
        int l, r, k;
        cin >> l >> r >> k;
        l--, r--;
        
        int ans = query(root[r], (l==0)?null:root[l-1], 0, comp_sz-1, k);
        
        cout << comp[ans] << endl;
    }
}
