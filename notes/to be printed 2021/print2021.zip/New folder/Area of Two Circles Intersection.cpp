D. Area of Two Circles' Intersection


ld cosRule(ld a, ld b, ld c) {
        // Handle denom = 0
	ld res = (b * b - a * a + c * c ) / ((ld)2.00 * b * c);
    if ( fabs(res-1)<EPS)
        res = 1;
    if ( fabs(res+1)<EPS)
        res = -1;
	return acos(res);
}

int circleCircleIntersection(const point &c1, const ld&r1,
		const point &c2, const ld&r2, point &res1, point &res2) {
	if (same(c1,c2) && fabs(r1 - r2) < EPS) {
		res1 = res2 = c1;
		return fabs(r1) < EPS ? 1 : OO;
	}
	ld len = length(vec(c1,c2));
	if (fabs(len - (r1 + r2)) < EPS || fabs(fabs(r1 - r2) - len) < EPS) {
		point d, c;
		ld r;
		if (r1 > r2)
			d = vec(c1,c2), c = c1, r = r1;
		else
			d = vec(c2,c1), c = c2, r = r2;
		res1 = res2 = normalize(d) * r + c;
		return 1;
	}
	if (len > r1 + r2 || len < fabs(r1 - r2))
		return 0;
	ld a = cosRule(r2, r1, len);
	point c1c2 = normalize(vec(c1,c2)) * r1;
	res1 = rotate(c1c2,a) + c1;
	res2 = rotate(c1c2,-a) + c1;
	return 2;
}

ld CenterSectorArea( ld Halftheta , ld r ){
    return r*r*Halftheta ;
}

point cen[2] ;
ld r[2] ,x,y , d ;

bool check() {

    if ( same(cen[0] , cen[1] ) && r[0] == r[1] ){
        cout << PI * r[0] * r[0] << "\n" ;
        return 1;
    }
    if ( d + r[0] <= r[1] ) {
        cout << PI * r[0] * r[0] << "\n" ;
        return 1;
    }
    if ( d + r[1] <= r[0] ){
        cout << PI * r[1] * r[1] << "\n" ;
        return 1;
    }
    return 0 ;
}
int main()
{

    ios_base::sync_with_stdio(0); cin.tie(0); cout.tie(0);

    #ifdef LOCAL
        freopen("input.txt", "r", stdin);
        freopen("output.txt", "w", stdout);
    #endif // LOCAL
    cout << fixed << setprecision(20) ;
    {
        for ( int i = 0 ; i < 2 ; i++ ){
            cin >> x >> y >> r[i] ;
            cen[i] = {x,y} ;
        }
        d = length(vec(cen[0],cen[1]) ) ;
        if ( check() )
            return 0 ;
        point cut1 , cut2 ;
        ll cnt = circleCircleIntersection( cen[0] , r[0] , cen[1] , r[1] , cut1 , cut2 ) ;

        if ( cnt != 2 ){
            cout << 0 << "\n" ;
            return 0 ;
        }


        ld alpha = cosRule( r[0] , r[1] , d ) ;
        ld beta  = cosRule( r[1] , r[0] , d ) ;

        ld area1 = CenterSectorArea ( alpha , r[1] ) - r[1]*r[1]*cos(alpha)*sin(alpha) ;
        area1   += CenterSectorArea ( beta  , r[0] ) - r[0]*r[0]*cos(beta )*sin(beta ) ;
        cout << area1 ;
    }

}