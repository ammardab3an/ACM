// Problem: H. Subsequences (hard version)
// dp with lst char array

int n, k;
char str[111];
int lst[111][26];
int dp[111][111];

int32_t main(){
    
    
    cin >> n >> k >> str;
    
    memset(lst, -1, sizeof lst);
    
    for(int i = 0; i < n; i++){
        
        if(i) for(int j = 0; j < 26; j++) 
            lst[i][j] = lst[i-1][j];
        
        lst[i][str[i]-'a'] = i;
    }
    
    for(int i = 0; i < n; i++){
        dp[i][1] = 1;
    }
    
    for(int l = 2; l <= n; l++){
        
        for(int i = n-1; i >= 1; i--){
            
            for(int j = 0; j < 26; j++) if(lst[i-1][j] != -1){
                dp[i][l] += dp[lst[i-1][j]][l-1];
                dp[i][l] = min(dp[i][l], int(1e12));
            }
        }
    }
    
    int ans = 0;
    for(int l = n; l >= 1; l--){
        
        int cnt = 0;
        
        for(int j = 0; j < 26; j++) if(lst[n-1][j] != -1){
            cnt += dp[lst[n-1][j]][l];
            cnt = min(cnt, int(1e18));
        }
        
        if(cnt >= k){
            ans += (n-l) * k;
            k = 0;
            break;
        }
        else{
            ans += (n-l) * cnt;
            k -= cnt;
        }
    }
    
    if(k == 1){
        ans += n;
        k--;
    }
    
    cout << (k ? -1 : ans) << endl;
}
