// Problem: persistent seg (without pointers) D-query

struct node{
    
    int sum, left, right;
    
    node() :
        sum(0), left(0), right(0) {};
    
    node(int sum, int l, int r) :
        sum(sum), left(l), right(r) {};
};

int root[NMAX];
int rt = 1, sz = 1;
node nodes[16 * NMAX];
int lpos[AMAX];

// root[0] = null

int copy(int v, int &u){
    nodes[sz] = nodes[v];
    return u = sz++;
}

void update(int v , int l, int r, int p, int x){
    
    nodes[v].sum += x;
    
    if(l == r){
        return;
    }    
    
    int mid = (l+r)/2;
    if(p <= mid){
        update(copy(nodes[v].left, nodes[v].left), l, mid, p, x);
    }
    else{
        update(copy(nodes[v].right, nodes[v].right), mid+1, r, p, x);
    }
}

int query(int v, int l, int r, int q_l, int q_r){
    
    if(l > q_r || q_l > r){
        return 0;
    }    
    if(q_l <= l && r <= q_r){
        return nodes[v].sum;
    }
    int mid = (l+r)/2;
    int stPath = query(nodes[v].left, l, mid, q_l, q_r);
    int ndPath = query(nodes[v].right, mid+1, r, q_l, q_r);
    return stPath + ndPath;
}

int32_t main(){
    
    fastIO;
    
    int n;
    cin >> n;
    
    for(int i = 1; i <= n; i++){
        
        int ai;
        cin >> ai;
        
        copy(root[i-1], root[i]);
        
        update(root[i], 0, n, lpos[ai], -1);
        update(root[i], 0, n, lpos[ai]=i, +1);
    }
    
    int q; cin >> q; while(q--){
        int l, r;
        cin >> l >> r;
        cout << query(root[r], 0, n, l, r) << endl;
    }
}